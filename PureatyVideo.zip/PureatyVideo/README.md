# vertvideo - Watch vertial videos and upload your own

## Features
* Seamlessly scroll through videos
* tap to mute
* upload your videos
* watch them in realtime

## Technology stack used
* Firebase
* Exoplayer
* recycler view
* implementing texture view
